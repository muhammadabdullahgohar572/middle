'use client'

export default function PageError({error ,rest}) {
 
    return <p>error...</p>;
  }
  