
export const metadata=()=>{
  title:"Home"
}
export default function Home() {
  return (
  <>
  
  Wellcome to work  manager
  </>
  );
}
