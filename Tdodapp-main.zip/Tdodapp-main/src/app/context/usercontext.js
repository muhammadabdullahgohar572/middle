"use client"; // Add this directive at the top

import { createContext } from "react";

const usercontext = createContext({});

export default usercontext;
